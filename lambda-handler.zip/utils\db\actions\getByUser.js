"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getByUser = getByUser;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function getByUser(userId, limit = 10) {
    try {
        const result = await client_1.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: client_1.TableName,
            IndexName: "UserIndex",
            KeyConditionExpression: "userId = :u",
            ExpressionAttributeValues: { ":u": userId },
            Limit: limit,
        }));
        return result.Items;
    }
    catch {
        console.warn("Using fake db");
        return notifications_1.notifications.filter((n) => n.userId === userId).slice(0, limit);
    }
}
