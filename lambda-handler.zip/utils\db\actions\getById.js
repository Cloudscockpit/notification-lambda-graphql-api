"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getById = getById;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function getById(id) {
    try {
        const result = await client_1.docClient.send(new lib_dynamodb_1.GetCommand({ TableName: client_1.TableName, Key: { id } }));
        return result.Item;
    }
    catch {
        console.warn("Using fake db");
        return notifications_1.notifications.find((n) => n.id === id);
    }
}
