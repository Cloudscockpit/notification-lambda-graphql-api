"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Query = void 0;
const notifications_1 = require("../data/notifications");
const getAll_1 = require("../utils/db/actions/getAll");
const getById_1 = require("../utils/db/actions/getById");
const getByUser_1 = require("../utils/db/actions/getByUser");
const getByBoard_1 = require("../utils/db/actions/getByBoard");
exports.Query = {
    async notifications(limit = 10, offset = 0) {
        try {
            const result = await (0, getAll_1.getAll)(limit, offset);
            return result;
        }
        catch (err) {
            console.warn(' DynamoDB unavailable, using local fallback');
            return notifications_1.notifications.slice(offset, offset + limit);
        }
    },
    async notification(id) {
        try {
            return await (0, getById_1.getById)(id);
        }
        catch (err) {
            console.warn(' DynamoDB unavailable, using local fallback');
            return notifications_1.notifications.find((n) => n.id === id);
        }
    },
    async notificationsByUser(userId, limit = 10, offset = 0) {
        try {
            return await (0, getByUser_1.getByUser)(userId, limit);
        }
        catch (err) {
            console.warn(' DynamoDB unavailable, using local fallback');
            return notifications_1.notifications.filter((n) => n.userId === userId).slice(offset, offset + limit);
        }
    },
    async notificationsByBoard(boardId, limit = 10, offset = 0) {
        try {
            return await (0, getByBoard_1.getByBoard)(boardId, limit);
        }
        catch (err) {
            console.warn(' DynamoDB unavailable, using local fallback');
            return notifications_1.notifications.filter((n) => n.boardId === boardId).slice(offset, offset + limit);
        }
    },
};
