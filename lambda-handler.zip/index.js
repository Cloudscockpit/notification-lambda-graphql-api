"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const query_1 = require("./resolvers/query");
const mutation_1 = require("./resolvers/mutation");
const handler = async (event) => {
    try {
        const { fieldName, arguments: args } = event;
        switch (fieldName) {
            case "notifications":
                return await query_1.Query.notifications(args?.limit, args?.offset);
            case "notification":
                return await query_1.Query.notification(args?.id);
            case "notificationsByUser":
                return await query_1.Query.notificationsByUser(args?.userId, args?.limit, args?.offset);
            case "notificationsByBoard":
                return await query_1.Query.notificationsByBoard(args?.boardId, args?.limit, args?.offset);
            case "createNotification":
                return await mutation_1.Mutation.createNotification(args?.input);
            case "deleteNotification":
                return await mutation_1.Mutation.deleteNotification(args?.id);
            case "createNotificationForUser":
                return await mutation_1.Mutation.createNotificationForUser(args?.input);
            case "createNotificationForBoard":
                return await mutation_1.Mutation.createNotificationForBoard(args?.input);
            default:
                throw new Error(`Unknown field: ${fieldName}`);
        }
    }
    catch (error) {
        console.error("Handler error:", error);
        return { error: error.message || "Unexpected error occurred" };
    }
};
exports.handler = handler;
