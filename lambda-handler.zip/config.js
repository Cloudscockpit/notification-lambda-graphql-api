"use strict";
// import dotenv from "dotenv";
// import z from "zod";
Object.defineProperty(exports, "__esModule", { value: true });
exports.envConfig = void 0;
// dotenv.config(); 
// export const envConfigSchema = z.object({
//   aws: z.object({
//     accessKeyId: z.string(),
//     secretAccessKey: z.string(),
//     region: z.string().default("us-east-1"),
//   }),
//   notifications: z.string(),
// });
// export const envConfig = envConfigSchema.parse({
//   aws: {
//     accessKeyId: process.env.AWS_ACCESS_KEY_ID,
//     secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
//     region: process.env.AWS_REGION,
//   },
//   notifications: process.env.NOTIFICATION_TABLE,
// });
// Simple environment configuration without zod
exports.envConfig = {
    aws: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
        region: process.env.AWS_REGION || 'us-east-1',
    },
    notifications: process.env.NOTIFICATION_TABLE || '',
};
// Basic validation
if (!exports.envConfig.aws.accessKeyId) {
    throw new Error('AWS_ACCESS_KEY_ID environment variable is required');
}
if (!exports.envConfig.aws.secretAccessKey) {
    throw new Error('AWS_SECRET_ACCESS_KEY environment variable is required');
}
if (!exports.envConfig.notifications) {
    throw new Error('NOTIFICATION_TABLE environment variable is required');
}
