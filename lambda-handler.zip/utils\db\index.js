"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.db = void 0;
const getAll_1 = require("./actions/getAll");
const getById_1 = require("./actions/getById");
const getByUser_1 = require("./actions/getByUser");
const getByBoard_1 = require("./actions/getByBoard");
const create_1 = require("./actions/create");
const delete_1 = require("./actions/delete");
exports.db = {
    getAll: getAll_1.getAll,
    getById: getById_1.getById,
    getByUser: getByUser_1.getByUser,
    getByBoard: getByBoard_1.getByBoard,
    create: create_1.create,
    delete: delete_1.deleteById,
};
