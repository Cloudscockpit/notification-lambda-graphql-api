"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
async function runGetTests() {
    const printSeparator = () => console.log('\n----------------------------\n');
    const asNotifications = (value) => {
        if (!Array.isArray(value))
            return [];
        return value.filter(item => item && 'id' in item);
    };
    const asNotification = (value) => {
        if (!value || typeof value !== 'object' || !('id' in value))
            return undefined;
        return value;
    };
    console.log('--- All notifications ---');
    const allRaw = await (0, index_1.handler)({ fieldName: 'notifications', arguments: { limit: 10, offset: 0 } });
    const allNotifications = asNotifications(allRaw);
    console.log(allNotifications);
    printSeparator();
    const firstId = allNotifications[0]?.id;
    if (firstId) {
        console.log('--- Notification by ID ---');
        const notificationRaw = await (0, index_1.handler)({ fieldName: 'notification', arguments: { id: firstId } });
        const notification = asNotification(notificationRaw);
        console.log(notification);
        printSeparator();
    }
    console.log('--- Notifications by User ---');
    const byUserRaw = await (0, index_1.handler)({ fieldName: 'notificationsByUser', arguments: { userId: '103', limit: 10, offset: 0 } });
    const byUser = asNotifications(byUserRaw);
    console.log(byUser);
    printSeparator();
    console.log('--- Notifications by Board ---');
    const byBoardRaw = await (0, index_1.handler)({ fieldName: 'notificationsByBoard', arguments: { boardId: '503', limit: 10, offset: 0 } });
    const byBoard = asNotifications(byBoardRaw);
    console.log(byBoard);
    printSeparator();
}
runGetTests().catch(console.error);
