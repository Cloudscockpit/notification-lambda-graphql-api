"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.now = exports.generateId = void 0;
const generateId = () => Math.random().toString(36).substring(2, 10);
exports.generateId = generateId;
const now = () => new Date().toISOString();
exports.now = now;
