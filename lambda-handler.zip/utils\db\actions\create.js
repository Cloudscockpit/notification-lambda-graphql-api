"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.create = create;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function create(notification) {
    try {
        await client_1.docClient.send(new lib_dynamodb_1.PutCommand({ TableName: client_1.TableName, Item: notification }));
    }
    catch {
        console.warn("Using fake db");
        notifications_1.notifications.push(notification);
    }
    return notification;
}
