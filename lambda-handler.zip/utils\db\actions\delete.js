"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteById = deleteById;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function deleteById(id) {
    try {
        await client_1.docClient.send(new lib_dynamodb_1.DeleteCommand({ TableName: client_1.TableName, Key: { id } }));
        return true;
    }
    catch {
        console.warn("Using fake db");
        const index = notifications_1.notifications.findIndex((n) => n.id === id);
        if (index !== -1) {
            notifications_1.notifications.splice(index, 1);
            return true;
        }
        return false;
    }
}
