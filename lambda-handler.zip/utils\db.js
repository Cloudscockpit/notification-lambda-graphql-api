"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.db = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const notifications_1 = require("../data/notifications");
const config_1 = require("../config");
const client = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || "us-east-1",
});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TableName = config_1.envConfig.notifications || "Notifications";
exports.db = {
    async getAll(limit = 10, offset = 0) {
        try {
            const result = await docClient.send(new lib_dynamodb_1.ScanCommand({ TableName, Limit: limit }));
            return result.Items;
        }
        catch (err) {
            console.warn("Using fake db");
            return notifications_1.notifications.slice(offset, offset + limit);
        }
    },
    async getById(id) {
        try {
            const result = await docClient.send(new lib_dynamodb_1.GetCommand({ TableName, Key: { id } }));
            return result.Item;
        }
        catch (err) {
            console.warn("Using fake db");
            return notifications_1.notifications.find((n) => n.id === id);
        }
    },
    async getByUser(userId, limit = 10) {
        try {
            const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
                TableName,
                IndexName: "UserIndex",
                KeyConditionExpression: "userId = :u",
                ExpressionAttributeValues: { ":u": userId },
                Limit: limit,
            }));
            return result.Items;
        }
        catch (err) {
            console.warn("Using fake db");
            return notifications_1.notifications.filter((n) => n.userId === userId).slice(0, limit);
        }
    },
    async getByBoard(boardId, limit = 10) {
        try {
            const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
                TableName,
                IndexName: "BoardIndex",
                KeyConditionExpression: "boardId = :b",
                ExpressionAttributeValues: { ":b": boardId },
                Limit: limit,
            }));
            return result.Items;
        }
        catch (err) {
            console.warn("Using fake db");
            return notifications_1.notifications.filter((n) => n.boardId === boardId).slice(0, limit);
        }
    },
    async create(notification) {
        try {
            await docClient.send(new lib_dynamodb_1.PutCommand({ TableName, Item: notification }));
        }
        catch {
            console.warn("Using fake db");
            notifications_1.notifications.push(notification);
        }
        return notification;
    },
    async delete(id) {
        try {
            await docClient.send(new lib_dynamodb_1.DeleteCommand({ TableName, Key: { id } }));
            return true;
        }
        catch {
            console.warn("Using fake db");
            const index = notifications_1.notifications.findIndex((n) => n.id === id);
            if (index !== -1) {
                notifications_1.notifications.splice(index, 1);
                return true;
            }
            return false;
        }
    },
};
