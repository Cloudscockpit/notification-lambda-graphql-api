"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.notifications = void 0;
exports.notifications = [
    {
        id: '1',
        message: 'Welcome to the workspace.',
        userId: '101',
        boardId: '501',
        createdAt: new Date().toISOString(),
    },
    {
        id: '2',
        message: 'You have a new task assigned.',
        userId: '102',
        boardId: '502',
        createdAt: new Date().toISOString(),
    },
];
