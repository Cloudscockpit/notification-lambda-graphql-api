"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
async function runDeleteTests() {
    const printSeparator = () => console.log('\n----------------------------\n');
    const asNotifications = (value) => {
        if (!Array.isArray(value))
            return [];
        return value.filter(item => item && 'id' in item);
    };
    let allNotifications = asNotifications(await (0, index_1.handler)({
        fieldName: 'notifications',
        arguments: { limit: 10, offset: 0 }
    }));
    if (allNotifications.length === 0) {
        console.log('No notifications to delete.');
        return;
    }
    const lastNotification = allNotifications[allNotifications.length - 1];
    const deleted = await (0, index_1.handler)({
        fieldName: 'deleteNotification',
        arguments: { id: lastNotification.id }
    });
    console.log('Deleted:', deleted);
    printSeparator();
    const remaining = asNotifications(await (0, index_1.handler)({
        fieldName: 'notifications',
        arguments: { limit: 10, offset: 0 }
    }));
    console.log('Remaining notifications:', remaining);
    printSeparator();
}
runDeleteTests().catch(console.error);
