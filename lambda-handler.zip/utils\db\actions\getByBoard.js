"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getByBoard = getByBoard;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function getByBoard(boardId, limit = 10) {
    try {
        const result = await client_1.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: client_1.TableName,
            IndexName: "BoardIndex",
            KeyConditionExpression: "boardId = :b",
            ExpressionAttributeValues: { ":b": boardId },
            Limit: limit,
        }));
        return result.Items;
    }
    catch {
        console.warn("Using fake db");
        return notifications_1.notifications.filter((n) => n.boardId === boardId).slice(0, limit);
    }
}
