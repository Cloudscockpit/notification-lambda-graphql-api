"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Mutation = void 0;
const crypto_1 = require("crypto");
const create_1 = require("../utils/db/actions/create");
const delete_1 = require("../utils/db/actions/delete");
exports.Mutation = {
    async createNotification({ message, userId, boardId, }) {
        const newNotification = {
            id: (0, crypto_1.randomUUID)(),
            message,
            userId,
            boardId,
            createdAt: new Date().toISOString(),
        };
        await (0, create_1.create)(newNotification);
        return newNotification;
    },
    async deleteNotification(id) {
        return await (0, delete_1.deleteById)(id);
    },
    async createNotificationForUser({ message, userId, }) {
        const newNotification = {
            id: (0, crypto_1.randomUUID)(),
            message,
            userId,
            createdAt: new Date().toISOString(),
        };
        await (0, create_1.create)(newNotification);
        return newNotification;
    },
    async createNotificationForBoard({ message, boardId, }) {
        const newNotification = {
            id: (0, crypto_1.randomUUID)(),
            message,
            boardId,
            createdAt: new Date().toISOString(),
        };
        await (0, create_1.create)(newNotification);
        return newNotification;
    },
};
