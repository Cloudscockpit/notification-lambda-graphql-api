"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAll = getAll;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_1 = require("../client");
const notifications_1 = require("../../../data/notifications");
async function getAll(limit = 10, offset = 0) {
    try {
        const result = await client_1.docClient.send(new lib_dynamodb_1.ScanCommand({ TableName: client_1.TableName, Limit: limit }));
        return result.Items;
    }
    catch {
        console.warn("Using fake db");
        return notifications_1.notifications.slice(offset, offset + limit);
    }
}
